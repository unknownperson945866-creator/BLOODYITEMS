# BLOODYITEMS

A Java 21 / Paper 1.21.11 custom-content plugin starter. It includes YAML-defined custom items, persistent item IDs, MiniMessage names/lore, crafting recipes, simple placeable ItemDisplay furniture, commands, and a resource-pack ZIP generator.

## Build
1. Install JDK 21 and Gradle 8.7+ (or open this project in IntelliJ IDEA).
2. Run `gradle clean build`.
3. Copy `build/libs/BLOODYITEMS-1.0.0.jar` to `plugins/`.
4. Start Paper once, then stop it.

## Install / first run
- Edit `plugins/BLOODYITEMS/items/*.yml`.
- Put PNG textures in `plugins/BLOODYITEMS/pack/assets/bloodyitems/textures/item/`.
- Run `/bi reload`, then `/bi pack`.
- The ZIP is created at `plugins/BLOODYITEMS/BLOODYITEMS-pack.zip`.
- Host that ZIP and configure the resource-pack URL/hash in Paper's server resource-pack settings. The plugin does not upload or host the pack automatically.

## Commands
- `/bi help`
- `/bi list`
- `/bi give <player> <id> [amount]`
- `/bi reload`
- `/bi pack`

Permission: `bloodyitems.admin` (default OP).

## Add an item
Create `plugins/BLOODYITEMS/items/ember_blade.yml`:
```yaml
id: ember_blade
material: NETHERITE_SWORD
display-name: "<gradient:#ff8a00:#ff2020><bold>Ember Blade</bold></gradient>"
lore:
  - "<gray>A custom weapon."
custom-model: "bloodyitems:ember_blade"
glow: true
unbreakable: false
placeable: false
recipe:
  shape:
    - " F "
    - " F "
    - " S "
  ingredients:
    F: BLAZE_POWDER
    S: STICK
```
Add `ember_blade.png` to `pack/assets/bloodyitems/textures/item/`, then run `/bi reload` and `/bi pack`.

## Important limitations / next development stage
- Set `resource-pack.pack-format` to the exact format required by the Minecraft client version you target. The default is a starting value, not a guarantee for every 1.21.x patch.
- This first source release implements custom item definitions, recipes, and basic display-entity placement. It does not yet implement full furniture hitboxes/rotation/removal, block-state replacement, armor equipment models, sound packs, GUI editor, pack hosting, or a pack hash/URL workflow.
- Custom models require the matching resource pack on clients. Without it, items still work but may show the base material appearance.
- Resource-pack model definitions follow the modern 1.21.4+ item-definition layout; test against your exact client build before production use.
