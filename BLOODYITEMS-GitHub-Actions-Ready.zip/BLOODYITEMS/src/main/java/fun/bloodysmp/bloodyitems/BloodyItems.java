package fun.bloodysmp.bloodyitems;

import fun.bloodysmp.bloodyitems.command.BICommand;
import fun.bloodysmp.bloodyitems.content.ContentManager;
import fun.bloodysmp.bloodyitems.listener.ContentListener;
import fun.bloodysmp.bloodyitems.pack.ResourcePackGenerator;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

public final class BloodyItems extends JavaPlugin {
    private ContentManager contentManager;
    private NamespacedKey itemIdKey;
    private NamespacedKey furnitureKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("items/ruby_sword.yml", false);
        saveResource("items/ruby_block.yml", false);
        getDataFolder().mkdirs();
        itemIdKey = new NamespacedKey(this, "item_id");
        furnitureKey = new NamespacedKey(this, "furniture");

        contentManager = new ContentManager(this);
        contentManager.reload();

        getServer().getPluginManager().registerEvents(
                new ContentListener(this, contentManager, itemIdKey, furnitureKey), this);

        BICommand command = new BICommand(this, contentManager);
        if (getCommand("bloodyitems") != null) {
            getCommand("bloodyitems").setExecutor(command);
            getCommand("bloodyitems").setTabCompleter(command);
        }

        getLogger().info("BLOODYITEMS enabled. Loaded " + contentManager.getItems().size() + " definitions.");
    }

    public ContentManager content() { return contentManager; }
    public NamespacedKey itemIdKey() { return itemIdKey; }
    public NamespacedKey furnitureKey() { return furnitureKey; }

    public void reloadPlugin() {
        reloadConfig();
        contentManager.reload();
    }

    public void generatePack() throws Exception {
        new ResourcePackGenerator(this, contentManager).generate();
    }
}
