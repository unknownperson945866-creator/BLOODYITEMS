package fun.bloodysmp.bloodyitems.content;

import java.util.List;
import java.util.Map;

public record ItemDefinition(
        String id, String material, String displayName, List<String> lore,
        String customModel, boolean glow, boolean unbreakable, boolean placeable,
        List<String> recipeShape, Map<String, String> recipeIngredients
) {}
