package fun.bloodysmp.bloodyitems.listener;

import fun.bloodysmp.bloodyitems.BloodyItems;
import fun.bloodysmp.bloodyitems.content.ContentManager;
import fun.bloodysmp.bloodyitems.content.ItemDefinition;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;

public final class ContentListener implements Listener {
    private final BloodyItems plugin;
    private final ContentManager content;
    private final org.bukkit.NamespacedKey itemIdKey, furnitureKey;

    public ContentListener(BloodyItems plugin, ContentManager content,
                           org.bukkit.NamespacedKey itemIdKey, org.bukkit.NamespacedKey furnitureKey) {
        this.plugin = plugin; this.content = content; this.itemIdKey = itemIdKey; this.furnitureKey = furnitureKey;
    }

    @EventHandler
    public void onPlace(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null || event.getItem() == null) return;
        String id = event.getItem().getItemMeta().getPersistentDataContainer().get(itemIdKey, PersistentDataType.STRING);
        if (id == null) return;
        ItemDefinition def = content.get(id);
        if (def == null || !def.placeable()) return;

        Location location = event.getClickedBlock().getRelative(event.getBlockFace()).getLocation().add(0.5, 0.05, 0.5);
        event.setCancelled(true);
        ItemDisplay display = (ItemDisplay) location.getWorld().spawnEntity(location, EntityType.ITEM_DISPLAY);
        display.setItemStack(content.create(def));
        display.getPersistentDataContainer().set(furnitureKey, PersistentDataType.STRING, id);
        display.setPersistent(true);
        if (event.getPlayer().getGameMode() != org.bukkit.GameMode.CREATIVE) {
            var hand = event.getPlayer().getInventory().getItemInMainHand();
            hand.setAmount(hand.getAmount() - 1);
        }
    }
}
