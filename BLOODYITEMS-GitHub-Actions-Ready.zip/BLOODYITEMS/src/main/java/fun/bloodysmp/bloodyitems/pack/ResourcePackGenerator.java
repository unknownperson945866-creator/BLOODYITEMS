package fun.bloodysmp.bloodyitems.pack;

import fun.bloodysmp.bloodyitems.BloodyItems;
import fun.bloodysmp.bloodyitems.content.ContentManager;
import fun.bloodysmp.bloodyitems.content.ItemDefinition;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.*;
import java.nio.file.*;
import java.util.zip.*;

public final class ResourcePackGenerator {
    private final BloodyItems plugin;
    private final ContentManager content;
    public ResourcePackGenerator(BloodyItems plugin, ContentManager content) { this.plugin = plugin; this.content = content; }

    public void generate() throws IOException {
        Path base = plugin.getDataFolder().toPath().resolve("pack");
        Path assets = base.resolve("assets/bloodyitems");
        Files.createDirectories(assets.resolve("models/item"));
        Files.createDirectories(assets.resolve("textures/item"));
        Files.createDirectories(assets.resolve("items"));
        Path mcmeta = base.resolve("pack.mcmeta");
        int format = plugin.getConfig().getInt("resource-pack.pack-format", 75);
        String description = plugin.getConfig().getString("resource-pack.description", "BLOODYITEMS");
        Files.writeString(mcmeta, "{\n  \"pack\": { \"pack_format\": " + format + ", \"description\": \"" + escape(description) + "\" }\n}\n");

        for (ItemDefinition def : content.getItems()) {
            String path = def.id().replaceAll("[^a-zA-Z0-9_/-]", "_");
            String model = "{\n  \"parent\": \"item/generated\",\n  \"textures\": { \"layer0\": \"bloodyitems:item/" + path + "\" }\n}\n";
            Path modelPath = assets.resolve("models/item/" + path + ".json");
            Files.createDirectories(modelPath.getParent());
            Files.writeString(modelPath, model);
            // 1.21.4+ item definition points to the generated model.
            String itemDef = "{\n  \"model\": { \"type\": \"minecraft:model\", \"model\": \"bloodyitems:item/" + path + "\" }\n}\n";
            Path itemPath = assets.resolve("items/" + path + ".json");
            Files.createDirectories(itemPath.getParent());
            Files.writeString(itemPath, itemDef);
        }

        String output = plugin.getConfig().getString("resource-pack.output-file", "BLOODYITEMS-pack.zip");
        Path zip = plugin.getDataFolder().toPath().resolve(output);
        try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(zip))) {
            try (var stream = Files.walk(base)) {
                stream.filter(Files::isRegularFile).forEach(file -> {
                    String name = base.relativize(file).toString().replace('\\', '/');
                    try {
                        zos.putNextEntry(new ZipEntry(name));
                        Files.copy(file, zos);
                        zos.closeEntry();
                    } catch (IOException e) { throw new UncheckedIOException(e); }
                });
            } catch (UncheckedIOException e) { throw e.getCause(); }
        }
    }

    private String escape(String input) { return input.replace("\\", "\\\\").replace("\"", "\\\""); }
}
