package fun.bloodysmp.bloodyitems.content;

import fun.bloodysmp.bloodyitems.BloodyItems;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.configuration.file.YamlConfiguration;
import net.kyori.adventure.text.minimessage.MiniMessage;

import java.io.File;
import java.util.*;

public final class ContentManager {
    private final BloodyItems plugin;
    private final Map<String, ItemDefinition> items = new LinkedHashMap<>();

    public ContentManager(BloodyItems plugin) { this.plugin = plugin; }

    public void reload() {
        items.clear();
        File folder = new File(plugin.getDataFolder(), "items");
        if (!folder.exists()) folder.mkdirs();
        File[] files = folder.listFiles((dir, name) -> name.endsWith(".yml") || name.endsWith(".yaml"));
        if (files == null) return;

        for (File file : files) {
            YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
            String id = yml.getString("id", file.getName().replaceFirst("\\.ya?ml$", "")).toLowerCase(Locale.ROOT);
            String material = yml.getString("material", "PAPER").toUpperCase(Locale.ROOT);
            if (!id.matches("[a-z0-9_/-]+") || Material.matchMaterial(material) == null) {
                plugin.getLogger().warning("Skipping invalid item definition: " + file.getName());
                continue;
            }
            ItemDefinition def = new ItemDefinition(
                    id, material, yml.getString("display-name", "<white>" + id),
                    yml.getStringList("lore"), yml.getString("custom-model", "bloodyitems:" + id),
                    yml.getBoolean("glow"), yml.getBoolean("unbreakable"),
                    yml.getBoolean("placeable"), yml.getStringList("recipe.shape"),
                    stringMap(yml.getConfigurationSection("recipe.ingredients"))
            );
            items.put(id, def);
        }
        registerRecipes();
    }

    private Map<String, String> stringMap(org.bukkit.configuration.ConfigurationSection section) {
        Map<String, String> map = new HashMap<>();
        if (section != null) for (String key : section.getKeys(false)) map.put(key, section.getString(key, ""));
        return map;
    }

    private void registerRecipes() {
        for (ItemDefinition def : items.values()) {
            if (def.recipeShape() == null || def.recipeShape().isEmpty()) continue;
            try {
                NamespacedKey key = new NamespacedKey(plugin, def.id());
                plugin.getServer().removeRecipe(key);
                ShapedRecipe recipe = new ShapedRecipe(key, create(def));
                recipe.shape(def.recipeShape().toArray(String[]::new));
                for (var entry : def.recipeIngredients().entrySet()) {
                    if (entry.getKey().length() != 1) continue;
                    Material ingredient = Material.matchMaterial(entry.getValue());
                    if (ingredient != null) recipe.setIngredient(entry.getKey().charAt(0), ingredient);
                }
                plugin.getServer().addRecipe(recipe);
            } catch (Exception ex) {
                plugin.getLogger().warning("Could not register recipe for " + def.id() + ": " + ex.getMessage());
            }
        }
    }

    public ItemStack create(ItemDefinition def) {
        ItemStack stack = new ItemStack(Objects.requireNonNull(Material.matchMaterial(def.material())));
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(MiniMessage.miniMessage().deserialize(def.displayName()));
        if (!def.lore().isEmpty()) meta.lore(def.lore().stream().map(s -> MiniMessage.miniMessage().deserialize(s)).toList());
        meta.setUnbreakable(def.unbreakable());
        meta.getPersistentDataContainer().set(plugin.itemIdKey(), PersistentDataType.STRING, def.id());
        if (def.glow()) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
        }
        try { meta.setItemModel(NamespacedKey.fromString(def.customModel())); }
        catch (Exception ignored) { plugin.getLogger().warning("Invalid custom-model for " + def.id()); }
        stack.setItemMeta(meta);
        return stack;
    }

    public ItemDefinition get(String id) { return items.get(id.toLowerCase(Locale.ROOT)); }
    public Collection<ItemDefinition> getItems() { return Collections.unmodifiableCollection(items.values()); }
}
