package fun.bloodysmp.bloodyitems.command;

import fun.bloodysmp.bloodyitems.BloodyItems;
import fun.bloodysmp.bloodyitems.content.ContentManager;
import fun.bloodysmp.bloodyitems.content.ItemDefinition;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public final class BICommand implements CommandExecutor, TabCompleter {
    private final BloodyItems plugin;
    private final ContentManager content;
    public BICommand(BloodyItems plugin, ContentManager content) { this.plugin = plugin; this.content = content; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage("§c§lBLOODYITEMS §7| §f/bi give <player> <id> [amount], /bi list, /bi reload, /bi pack");
            return true;
        }
        if (!sender.hasPermission("bloodyitems.admin")) { sender.sendMessage("§cNo permission."); return true; }
        switch (args[0].toLowerCase()) {
            case "list" -> {
                sender.sendMessage("§cLoaded items: §f" + String.join(", ", content.getItems().stream().map(ItemDefinition::id).toList()));
            }
            case "reload" -> {
                plugin.reloadPlugin();
                sender.sendMessage("§aBLOODYITEMS reloaded. Loaded " + content.getItems().size() + " definitions.");
            }
            case "give" -> {
                if (args.length < 3) { sender.sendMessage("§cUsage: /bi give <player> <id> [amount]"); return true; }
                Player target = plugin.getServer().getPlayerExact(args[1]);
                ItemDefinition def = content.get(args[2]);
                if (target == null || def == null) { sender.sendMessage("§cPlayer or item not found."); return true; }
                int amount = 1;
                if (args.length > 3) try { amount = Math.max(1, Math.min(64, Integer.parseInt(args[3]))); } catch (NumberFormatException ignored) {}
                var item = content.create(def); item.setAmount(amount);
                target.getInventory().addItem(item).values().forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
                sender.sendMessage("§aGave " + amount + "x " + def.id() + " to " + target.getName());
            }
            case "pack" -> {
                sender.sendMessage("§eGenerating resource pack...");
                try { plugin.generatePack(); sender.sendMessage("§aPack generated in plugins/BLOODYITEMS/"); }
                catch (Exception ex) { sender.sendMessage("§cPack generation failed: " + ex.getMessage()); plugin.getLogger().severe("Pack generation failed: " + ex); }
            }
            default -> sender.sendMessage("§cUnknown subcommand. Use /bi help");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("help", "give", "list", "reload", "pack");
        if (args.length == 3 && args[0].equalsIgnoreCase("give"))
            return content.getItems().stream().map(ItemDefinition::id).filter(s -> s.startsWith(args[2].toLowerCase())).toList();
        return new ArrayList<>();
    }
}
